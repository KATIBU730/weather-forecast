# weather analysis to predict occurance of rain using regression analysis

flask is used in fronted 

<img src="https://github.com/sammypeter/weather-forcast/blob/main/1.png"> 

<img src="https://github.com/sammypeter/weather-forcast/blob/main/3.png">

<img src="https://github.com/sammypeter/weather-forcast/blob/main/4.png">
